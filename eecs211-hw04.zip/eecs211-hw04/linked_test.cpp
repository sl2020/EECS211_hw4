#include "linked_lib.h"

#include <UnitTest++/UnitTest++.h>
#include <memory>
#include <iostream>
#include <stdexcept>

using namespace std;


TEST(POP_FRONT) {
    List list = make_shared<ListNode>();
    List a = make_shared<ListNode>();
    List b = make_shared<ListNode>();
    List c = make_shared<ListNode>();
    list->data = 1;
    list->next = a;
    a->data = 2;
    a->next = b;
    b->data = 3;
    b->next = c;
    c->data = 4;
    c->next = nullptr;

    List error_test = nullptr;

    CHECK_EQUAL(1 ,pop_front(list)->data);
    CHECK(nullptr == pop_front(list)->next);
    CHECK_THROW(pop_front(error_test), runtime_error);
}

TEST(PUSH_BACK) {
    List list = make_shared<ListNode>();
    List a = make_shared<ListNode>();
    List b = make_shared<ListNode>();
    List c = make_shared<ListNode>();
    list->data = 1;
    list->next = a;
    a->data = 2;
    a->next = b;
    b->data = 3;
    b->next = c;
    c->data = 4;
    c->next = nullptr;
    push_back(list, 5);

    CHECK_EQUAL(5, list->next->next->next->next->data);
    CHECK(nullptr == list->next->next->next->next->next);

    List test = nullptr;
    push_back(test, 1);
    CHECK_EQUAL(1, test->data);

}

TEST(NTH_ELEMENT){
    List list = make_shared<ListNode>();
    List a = make_shared<ListNode>();
    List b = make_shared<ListNode>();
    List c = make_shared<ListNode>();
    list->data = 1;
    list->next = a;
    a->data = 2;
    a->next = b;
    b->data = 3;
    b->next = c;
    c->data = 4;
    c->next = nullptr;

    CHECK_EQUAL(1, nth_element(list, 0));
    CHECK_EQUAL(2, nth_element(list, 1));
    CHECK_EQUAL(4, nth_element(list, 3));

    CHECK_THROW(nth_element(list, 4), runtime_error);
    CHECK_THROW(nth_element(list, 458), runtime_error);
    CHECK_THROW(nth_element(list, -14), runtime_error);
}

TEST(filter_lt){
    List list = make_shared<ListNode>();
    List a = make_shared<ListNode>();
    List b = make_shared<ListNode>();
    List c = make_shared<ListNode>();
    list->data = 1;
    list->next = a;
    a->data = 2;
    a->next = b;
    b->data = 3;
    b->next = c;
    c->data = 4;
    c->next = nullptr;


    filter_lt(list, 3);
    CHECK_EQUAL(2, list->next->data);
    CHECK(nullptr == list->next->next);
    CHECK_EQUAL(1, list->data);

    List test = nullptr;
    filter_lt(test, 4);
    CHECK(test == nullptr);
}


// Example test case for push_back
// Testing push_back on a singleton
TEST(PUSH_BACK_OF_ONE_ELEMENT) {
    // Initialize the input linked-list to push_back
    List xs = make_shared<ListNode>();
    xs->data = 514;
    List ys = xs;

    push_back(xs, 2017211);

    // Check that the output is a 2-element linked-list with correct order
    CHECK_EQUAL(ys, xs);
    CHECK_EQUAL(514, xs->data);
    CHECK(xs->next != nullptr);
    CHECK_EQUAL(2017211, xs->next->data);
    // Note: It is impossible to apply CHECK_EQUAL on nullptr, so we use
    // CHECK and manually compares for equality
    CHECK(xs->next->next == nullptr);
}

// This function overloads the '<<' operator to enable printing on List
// types. For example, 'cout << xs << '\n';' will compile and print its
// content. However, we are still not able to write tests such as
// CHECK_EQUAL(nullptr, xs) since nullptr might be of any pointer type
// and the '<<' operator does not know how to print it.
ostream& operator<<(ostream& out, const List& lst)
{
    if (lst) {
        out << "<ListNode@" << static_cast<void*>(lst.get());
        out << " data=" << lst->data;
        out << " next=" << static_cast<void*>(lst->next.get());
        out << ">";
    } else {
        out << "(nullptr)";
    }
    return out;
}
