#include <UnitTest++/UnitTest++.h>

int main()
{
    return UnitTest::RunAllTests();
}
