#include "linked_lib.h"

#include <memory>
#include <stdexcept>

using namespace std;

void filter_lt(List& front, int limit)
{
    List current = front;
    List contents;

    if(front != nullptr) {
        while (current->next != nullptr) {
            if (current->data < limit) {
                push_back(contents, current->data);
            }
            current = current->next;
        }
    }

    front = contents;
}

void push_back(List& front, int data)
{
    shared_ptr<ListNode> newNode = make_shared<ListNode>();
    newNode->data = data;
    newNode->next = nullptr;

    if(front == nullptr)
        front = newNode;
    else {
        List current = front;
        while(current->next != nullptr) {
            current = current->next;
        }
        current->next = newNode;
    }
}

List pop_front(List& front)
{
    if(front == nullptr)
        throw runtime_error("List passed into pop_front cannot be empty");

    List first = make_shared<ListNode>();
    first->data = front->data;
    first->next = nullptr;
    front = front->next;
    return first;
}

int& nth_element(List& front, size_t n)
{
    if(front == nullptr)
        throw runtime_error("List passed into nth_element cannot be empty");
    if(n < 0)
        throw runtime_error("Element number passed into nth_element cannot be negative");

    List current = front;
    for(int i = 0; i < n; ++i)
    {
        if(current->next == nullptr)
            throw runtime_error("index goes out of bounds");
        current = current->next;
    }

    return current->data;
}
